const mineflayer = require('mineflayer');

console.log('Starting...')

function createBot () {
    const bot = mineflayer.createBot({
    host: "zNhaan.aternos.me:29810",
    port: "29810",
    username: "zNhaan_Bot",
    version: false
    })
    bot.on('login', function() {
      bot.chat('/reginster 123123123 123123123')
      bot.chat('/login 123123123 123123123')
    })
    bot.on('chat', (username, message) => {
      if (username === bot.username) return
      switch (message) {
        case ';start':
          bot.chat('zNhaan_Bot treo server vip vải lồn )
          bot.setControlState('jump', true)
          break
          case ';stop':
            bot.chat('zNhaan_Bot đã dừng')
            bot.clearControlStates()
            break
          }
        })
        bot.on('spawn', function() {
          bot.chat('Bot > Spawned')
        })
        bot.on('death', function() {
          bot.chat('Bot > I died, respawn')
        })
        bot.on('kicked', (reason, loggedIn) => console.log(reason, loggedIn))
        bot.on('error', err => console.log(err))
        bot.on('end', createBot)
}
createBot()